﻿Install-Module PowerShellGet -Force

Install-Module -Name AzureRM -AllowClobber

Import-Module -Name AzureRM


Connect-AzureRmAccount