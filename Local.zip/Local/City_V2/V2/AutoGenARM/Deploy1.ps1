
#$subscriptionId = 'f2330bbc-2e83-44f9-8b1b-dad4e6734872'
$subscriptionId = '0073aa65-f55c-4013-9b95-975b5b3002c3'


$azureADFResourceGroupName = 'ADFaccelerator'
$dataFactoryName = 'adfaccelerator'  


$resourceGroupName = 'ADFaccelerator'

$Location = 'East US'

$LocationshortName = 'us-e'

$environment = 'dev'

$platform = 'demo' 

$StartTime = '2018-04-20T06:00:00.115Z' 
$StopTime = '2018-04-21T23:00:00Z'
$SourceBlobStorageConnectionString = 'DefaultEndpointsProtocol=https;AccountName=adfaccelerator2;AccountKey=/0N3ASyBQgGzUvKXx4CWIR55UIf6ZhNHxgOQ4U9hAzX3aYvbcusjqltHcl2yqEWX180yAt6MPRQnGVQ+PWB/PQ=='
$SourceFileName = 'zipcodes.csv'
$SourceFolderPath = 'adfaccelerator-blob0'
$SinkFileName = 'zipcodes.csv'
$SinkFolderPath = 'adfaccelerator-blob0'
$ADLSuri = 'https://indaccusightdlstore.azuredatalakestore.net/webhdfs/v1'
$ADLStenant = 'b5753e93-3d97-4bd8-ab83-1b305db6517e'
$ADLSsubscriptionId = '0073aa65-f55c-4013-9b95-975b5b3002c3'
$ADLSresourceGroupName = 'InD-Accusight-RG'

$StartTime_FullLoad ='2017-09-14T06:00:00.115Z' 
$EndTime_FullLoad = '2017-09-14T23:00:00Z'
    
$Offset = '06:00:00' 

$RootFilePath = 'C:\Users\ContainerAdministrator\CloudDrive'
 $CSVFilePath = 'C:\Users\ContainerAdministrator\CloudDrive'
  
 #get-content city__armtemplate.json
 
#******************************************************************************
# Script body
# Execution begins here
#******************************************************************************
 
# select subscription
Write-Host "Selecting subscription '$subscriptionId'";
Select-AzureRmSubscription -SubscriptionId $subscriptionId;
 

#Create or check for existing resource group  
$azureServiceFabricResourceGroup = Get-AzureRmResourceGroup -Name $azureADFResourceGroupName  -ErrorAction SilentlyContinue


$namingPrefix = 'WTW' + '-' + $platform.ToUpper() + '-' + $LocationshortName.ToUpper() + '-' + $environment.ToUpper() + '-'
 

$parameters=@{

    dataFactoryName = $dataFactoryName
    Location = $Location
    StartTime  = $StartTime 
    StopTime  = $StopTime 
    SourceBlobStorageConnectionString  = $SourceBlobStorageConnectionString 
    SourceFileName  = $SourceFileName 
    SourceFolderPath  = $SourceFolderPath 
    SinkFileName  = $SinkFileName 
    SinkFolderPath  = $SinkFolderPath 
    ADLSuri  = $ADLSuri 
    ADLStenant  = $ADLStenant 
    ADLSsubscriptionId  = $ADLSsubscriptionId 
    ADLSresourceGroupName  = $ADLSresourceGroupName 
     
}



# Start the deployment

$deploymentLabel =   $environment.ToLower() + 'ADFProvisioning'
Write-Host "Starting deployment...";
#===============================================================
#---------------------------------------------------------------
 

$global:templateFilePath  = $RootFilePath
#$global:ARMFilePath = $CSVFilePath
$global:ARMFilePath=''

$global:StartTime  = $StartTime
$global:EndTime = $StopTime

$global:StartTime_FullLoad  = $StartTime_FullLoad
$global:EndTime_FullLoad = $EndTime_FullLoad

$global:Offset  = $Offset 

$global:templateFilePath  = $RootFilePath
$global:ARMFilePath = $CSVFilePath
 
$global:StartTime_FullLoad  = $StartTime_FullLoad
$global:EndTime_FullLoad = $EndTime_FullLoad

$global:Offset  = $Offset 

# Iterate through a list of all CSV files in the folder and pipe it to ForEach-Object 
 #~Get-ChildItem  $global:templateFilePath -Name -Filter *.csv | ForEach-Object {
  Get-ChildItem  $global:ARMFilePath -Name -Filter *.csv | ForEach-Object {

 
    # derive source folder path and file name 
    #~$filePath =  $global:templateFilePath +"\"+ $_   
    $filePath =  $global:ARMFilePath +"\"+ $_   
    Write-Host " >>> filePath : " $filePath

    # Imports CSV file
    $global:csvFile = Import-Csv $filePath 
    $global:masterTemplatePath =""
     
    #Call ARM Automation script to generate ARM template
    invoke-expression -Command "$global:templateFilePath\GenerateTemplate_v2.ps1" 
  
    Test-AzureRmResourceGroupDeployment -ResourceGroupName $azureADFResourceGroupName  -TemplateParameterObject $parameters -TemplateFile $global:masterTemplatePath   -Verbose
    New-AzureRmResourceGroupDeployment -Name $deploymentLabel  -ResourceGroupName $azureADFResourceGroupName  -TemplateParameterObject $parameters -TemplateFile $global:masterTemplatePath   -Verbose
     
    
    Write-Host "Deployment completed for ";
    $global:masterTemplatePath
    $global:ARMFilePath
 Write-Host "===========================================================================================";
}
