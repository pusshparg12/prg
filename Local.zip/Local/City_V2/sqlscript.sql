 
create schema Geo


create table Geo.City(
CityID int not null,
CityName nvarchar(200) not null
)

 


create  type Geo.CityType as table(
CityID int not null,
CityName nvarchar(200) not null
)

 
alter proc spLoadCity  @City Geo.CityType READONLY, @JobName varchar(100)
as
Begin 

    
    Merge Geo.City c
    USING @City ct On c.CityID = ct.CityID
    When Matched Then
        Update Set c.CityName = ct.CityName
    When Not Matched Then
        Insert (CityID,CityName) 
            Values (ct.CityID,ct.CityName);
    

End