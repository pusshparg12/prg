 
create schema Geo


create table Geo.City(
CityID int not null,
CityName nvarchar(200) not null
)

 


create  type Geo.CityType as table(
CityID int not null,
CityName nvarchar(200) not null
)


create table Geo.zipcode(
zipid int IDENTITY(1,1) not null,
zipcode nvarchar(100) not null,
latitude nvarchar(100)  null,
longitude nvarchar(100)  null,
city nvarchar(100)  null,
state nvarchar(100)  null,
county nvarchar(100)  null 
)

alter proc spLoadCity  @City Geo.CityType READONLY, @JobName varchar(100)
as
Begin 

    
    Merge Geo.City c
    USING @City ct On c.CityID = ct.CityID
    When Matched Then
        Update Set c.CityName = ct.CityName
    When Not Matched Then
        Insert (CityID,CityName) 
            Values (ct.CityID,ct.CityName);
    

End