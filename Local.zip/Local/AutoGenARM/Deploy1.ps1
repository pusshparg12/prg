



#$subscriptionId = 'f2330bbc-2e83-44f9-8b1b-dad4e6734872'
$subscriptionId = '0073aa65-f55c-4013-9b95-975b5b3002c3'

$azureADFResourceGroupName = 'ADFaccelerator'
$dataFactoryName = 'ADF-Data-factory1'  


$resourceGroupName = 'ADFaccelerator'

$Location = 'East US'

$LocationshortName = 'us-e'

$environment = 'dev'

$platform = 'demo' 

$azureSqlServerName ='adfaccelerator'
$azureSqlServerUserName = 'adminuser'
$azureSqlServerPassword = 'Admin@Pw0d12'
$azureTargetDatabaseName = 'Demo-ADFaccelerator'

$OnPremSqlServerName = 'adfaccelerator'
$OnPremSqlServerUserName = 'adminuser'
$OnPremSqlServerPassword = 'Admin@Pw0d12'
$OnPremSourceDatabaseName = 'adfaccelerator'

#$OnPremGateway ='DGM-ADF-loadSQLServerData'

$StartTime ='2018-04-11T06:00:00.115Z' 
$EndTime = '2018-04-12T23:00:00Z'

$StartTime_FullLoad ='2017-09-14T06:00:00.115Z' 
$EndTime_FullLoad = '2017-09-14T23:00:00Z'
    
$Offset = '06:00:00' 

$RootFilePath = 'C:\Users\ContainerAdministrator\CloudDrive'
 $CSVFilePath = 'C:\Users\ContainerAdministrator\CloudDrive'
  
 
#******************************************************************************
# Script body
# Execution begins here
#******************************************************************************
 
# select subscription
Write-Host "Selecting subscription '$subscriptionId'";
Select-AzureRmSubscription -SubscriptionId $subscriptionId;
 

#Create or check for existing resource group  
$azureServiceFabricResourceGroup = Get-AzureRmResourceGroup -Name $azureADFResourceGroupName  -ErrorAction SilentlyContinue


$namingPrefix = 'WTW' + '-' + $platform.ToUpper() + '-' + $LocationshortName.ToUpper() + '-' + $environment.ToUpper() + '-'
 

$parameters=@{
    dataFactoryName = $dataFactoryName
    Location = $Location
    StartTime = $StartTime
    StopTime = $EndTime 

    azureSqlServerName = $azureSqlServerName
    azureSqlServerUserName = $azureSqlServerUserName
    azureSqlServerPassword = $azureSqlServerPassword
    azureTargetDatabaseName = $azureTargetDatabaseName

    OnPremSqlServerName = $OnPremSqlServerName
    OnPremSqlServerUserName = $OnPremSqlServerUserName
    OnPremSqlServerPassword = $OnPremSqlServerPassword
    OnPremSourceDatabaseName = $OnPremSourceDatabaseName 
    

}



# Start the deployment

$deploymentLabel =   $environment.ToLower() + 'ADFProvisioning'
Write-Host "Starting deployment...";
#===============================================================
#---------------------------------------------------------------
 

$global:templateFilePath  = $RootFilePath
#$global:ARMFilePath = $CSVFilePath
$global:ARMFilePath=''

$global:StartTime  = $StartTime
$global:EndTime = $EndTime

$global:StartTime_FullLoad  = $StartTime_FullLoad
$global:EndTime_FullLoad = $EndTime_FullLoad

$global:Offset  = $Offset 

$global:templateFilePath  = $RootFilePath
$global:ARMFilePath = $CSVFilePath

$global:StartTime  = $StartTime
$global:EndTime = $EndTime

$global:StartTime_FullLoad  = $StartTime_FullLoad
$global:EndTime_FullLoad = $EndTime_FullLoad

$global:Offset  = $Offset 

# Iterate through a list of all CSV files in the folder and pipe it to ForEach-Object 
 #~Get-ChildItem  $global:templateFilePath -Name -Filter *.csv | ForEach-Object {
  Get-ChildItem  $global:ARMFilePath -Name -Filter *.csv | ForEach-Object {

 
    # derive source folder path and file name 
    #~$filePath =  $global:templateFilePath +"\"+ $_   
    $filePath =  $global:ARMFilePath +"\"+ $_   
    Write-Host " >>> filePath : " $filePath

    # Imports CSV file
    $global:csvFile = Import-Csv $filePath 
    $global:masterTemplatePath =""
     
    #Call ARM Automation script to generate ARM template
    invoke-expression -Command "$global:templateFilePath\GenerateTemplate1.ps1" 
  
    Test-AzureRmResourceGroupDeployment -ResourceGroupName $azureADFResourceGroupName  -TemplateParameterObject $parameters -TemplateFile $global:masterTemplatePath   -Verbose
    New-AzureRmResourceGroupDeployment -Name $deploymentLabel  -ResourceGroupName $azureADFResourceGroupName  -TemplateParameterObject $parameters -TemplateFile $global:masterTemplatePath   -Verbose
     
    
    Write-Host "Deployment completed for ";
    $global:masterTemplatePath
    $global:ARMFilePath
 Write-Host "===========================================================================================";
}
