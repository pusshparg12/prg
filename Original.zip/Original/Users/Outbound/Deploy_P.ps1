


  

$subscriptionId = 'f2330bbc-2e83-44f9-8b1b-dad4e6734872'


$resourceGroupName = 'Azure-Data-Factory'

$Location = 'northeurope'

$LocationshortName = 'eu-n'

$environment = 'dev'

$platform = 'cft'

$azureSqlServerName ='wtw-cft-uk-s-dev-governanceadmin-sqldb'

$azureSqlServerUserName = 'adminuser'

$azureSqlServerPassword = 'Admin@Pw0d'

$azureTargetDatabaseName = 'UserManagement'

$OnPremSqlServerName = 'wtw-cft-uk-s-dev-platform-sharedservices-sqldb'


$OnPremSqlServerUserName = 'adminuser'
$OnPremSqlServerPassword = 'Admin@Pw0d'

$OnPremSourceDatabaseName = 'ReferenceData'

$OnPremGateway ='DGM-ADF-loadSQLServerData'
 
    
$StartTime ='2018-02-03T06:00:00.115Z' 
$EndTime = '2018-02-10T23:00:00Z'

$StartTime_FullLoad ='2018-02-03T06:00:00.115Z' 
$EndTime_FullLoad = '2018-02-03T23:00:00Z'
    

$Offset = '06:00:00'
$Offset_forFullLoad = '06:00:00'

$RootFilePath = 'C:\cft\wtw\Trunk\IntegrationLayer\ReferenceData\ARMTemplate\ARMTemplate\AutoGenARM'
 $CSVFilePath = 'C:\cft\wtw\Trunk\IntegrationLayer\ReferenceData\ARMTemplate\ARMTemplate\Users\Principal\Outbound'
  


<#
.SYNOPSIS
    Registers RPs
#>
Function RegisterRP {
    Param(
        [string]$ResourceProviderNamespace
    )

    Write-Host "Registering resource provider '$ResourceProviderNamespace'";
    Register-AzureRmResourceProvider -ProviderNamespace $ResourceProviderNamespace;
}

#******************************************************************************
# Script body
# Execution begins here
#******************************************************************************
$ErrorActionPreference = "Stop"

# The script has been tested on Powershell 3.0
Set-StrictMode -Version 3

import-module Azure

# sign in
Write-Host "Logging in...";
Add-AzureRmAccount 



# select subscription
Write-Host "Selecting subscription '$subscriptionId'";
Select-AzureRmSubscription -SubscriptionId $subscriptionId;

# Register RPs
$resourceProviders = @("microsoft.datafactory");
if($resourceProviders.length) {
    Write-Host "Registering resource providers"
    foreach($resourceProvider in $resourceProviders) {
        RegisterRP($resourceProvider);
    }
}

#Create or check for existing resource group
$azureADFResourceGroupName = 'WTW' + '-' + $platform.ToUpper() + '-' + $LocationshortName.ToUpper() + '-' + $environment.ToUpper() + '-Resource-Group-' + $resourceGroupName
$azureServiceFabricResourceGroup = Get-AzureRmResourceGroup -Name $azureADFResourceGroupName  -ErrorAction SilentlyContinue
if(!$azureServiceFabricResourceGroup)
{
  Write-Host "Resource group '$azureADFResourceGroupName' does not exist. To create a new resource group, please enter a location.";
  Write-Host "Creating resource group '$azureADFResourceGroupName' in location '$Location'";
  New-AzureRmResourceGroup -Name $azureADFResourceGroupName -Location $Location
}
else{
  Write-Host "Using existing resource group '$azureADFResourceGroupName'";
}

$namingPrefix = 'WTW' + '-' + $platform.ToUpper() + '-' + $LocationshortName.ToUpper() + '-' + $environment.ToUpper() + '-'

$dataFactoryName = $namingPrefix + 'ADF-IntegrationLayer'

$parameters=@{
    dataFactoryName = $dataFactoryName
    azureSqlServerName = $azureSqlServerName
    azureSqlServerUserName = $azureSqlServerUserName
    azureSqlServerPassword = $azureSqlServerPassword
    azureTargetDatabaseName = $azureTargetDatabaseName

    OnPremSqlServerName = $OnPremSqlServerName
    OnPremSqlServerUserName = $OnPremSqlServerUserName
    OnPremSqlServerPassword = $OnPremSqlServerPassword
    OnPremSourceDatabaseName = $OnPremSourceDatabaseName
    OnPremGateway = $OnPremGateway
    Location = $Location 
    offset_startTimePosition = $Offset
    StartTime = $StartTime
    StopTime = $EndTime
    StartTime_FullLoad = $StartTime_FullLoad
    StopTime_FullLoad = $EndTime_FullLoad   


}


# Start the deployment

$deploymentLabel =   $environment.ToLower() + 'ADFProvisioning'
Write-Host "Starting deployment...";
#===============================================================
#---------------------------------------------------------------
 

$global:templateFilePath  = $RootFilePath
$global:ARMFilePath = $CSVFilePath

$global:StartTime  = $StartTime
$global:EndTime = $EndTime

$global:StartTime_FullLoad  = $StartTime_FullLoad
$global:EndTime_FullLoad = $EndTime_FullLoad

$global:Offset  = $Offset
$global:Offset_forFullLoad  = $Offset_forFullLoad  

  

# Iterate through a list of all CSV files in the folder and pipe it to ForEach-Object 
 #~Get-ChildItem  $global:templateFilePath -Name -Filter *.csv | ForEach-Object {
  Get-ChildItem  $global:ARMFilePath -Name -Filter *.csv | ForEach-Object {

 
    # derive source folder path and file name 
    #~$filePath =  $global:templateFilePath +"\"+ $_   
    $filePath =  $global:ARMFilePath +"\"+ $_   
    Write-Host " >>> filePath : " $filePath

    # Imports CSV file
    $global:csvFile = Import-Csv $filePath 
    $global:masterTemplatePath =""
     
    #Call ARM Automation script to generate ARM template
    invoke-expression -Command "$global:templateFilePath\GenerateTemplate.ps1" 
  
    Test-AzureRmResourceGroupDeployment -ResourceGroupName $azureADFResourceGroupName  -TemplateParameterObject $parameters -TemplateFile $global:masterTemplatePath   -Verbose
    New-AzureRmResourceGroupDeployment -Name $deploymentLabel  -ResourceGroupName $azureADFResourceGroupName  -TemplateParameterObject $parameters -TemplateFile $global:masterTemplatePath   -Verbose
    
    Write-Host "Deployment completed for ";
    $global:masterTemplatePath
    $global:ARMFilePath
 Write-Host "===========================================================================================";
} #iterating each csv file
