<#
 .SYNOPSIS
    Deploys a Exchange Reference Data template to Azure

 .DESCRIPTION
    Deploys an Azure Resource Manager template for Exchange Reference Data

 .PARAMETER subscriptionId
    The subscription id where the template will be deployed.

 .PARAMETER resourceGroupName
    The resource group where the template will be deployed. Can be the name of an existing or a new resource group.

 .PARAMETER resourceGroupLocation
    Optional, a resource group location. If specified, will try to create a new resource group in this location. If not specified, assumes resource group is existing.

 .PARAMETER deploymentName
    The deployment name.

 .PARAMETER templateFilePath
    Optional, path to the template file. Defaults to template.json.

 .PARAMETER parametersFilePath
    Optional, path to the parameters file. Defaults to parameters.json. If file is not found, will prompt for parameter values based on template.
#>

param(
 
 [string]
 $resourceGroupName,

 [string]
 $Location,

 [string]
 $LocationshortName,

 [string]
 $environment,

 [string]
 $platform,

 [Parameter(Mandatory=$True)]
 [string]
 $azureSqlServerName,

 [Parameter(Mandatory=$True)]
 [string]
 $azureSqlServerUserName,

 [Parameter(Mandatory=$True)]
 [string]
 $azureSqlServerPassword,

 [Parameter(Mandatory=$True)]
 [string]
 $azureTargetDatabaseName,

 [Parameter(Mandatory=$True)]
 [string]
 $OnPremSqlServerName,
 
 [Parameter(Mandatory=$True)]
 [string]
 $OnPremSqlServerUserName,
 
 [Parameter(Mandatory=$True)]
 [string]
 $OnPremSqlServerPassword,
 
 [Parameter(Mandatory=$True)]
 [string]
 $OnPremSourceDatabaseName,
 
 [Parameter(Mandatory=$True)]
 [string]
 $OnPremGateway,
 
 [string]
 $Offset,
  
 [string]
 $StartTime,

 [string]
 $EndTime,

 [string]
 $StartTime_FullLoad,

 [string]
 $EndTime_FullLoad, 
  
 [Parameter(Mandatory=$True)]
 [string]
 $RootFilePath = "template.json", 
   
 [Parameter(Mandatory=$True)]
 [string]
 $CSVFilePath = "ColumnDetail.csv" 
   


)

<#
.SYNOPSIS
    Registers RPs
#>
Function RegisterRP {
    Param(
        [string]$ResourceProviderNamespace
    )

    Write-Host "Registering resource provider '$ResourceProviderNamespace'";
    Register-AzureRmResourceProvider -ProviderNamespace $ResourceProviderNamespace;
}

#******************************************************************************
# Script body
# Execution begins here
#******************************************************************************
$ErrorActionPreference = "Stop"

# The script has been tested on Powershell 3.0
Set-StrictMode -Version 3

import-module Azure

# Register RPs
$resourceProviders = @("microsoft.datafactory");
if($resourceProviders.length) {
    Write-Host "Registering resource providers"
    foreach($resourceProvider in $resourceProviders) {
        RegisterRP($resourceProvider);
    }
}

$global:templateFilePath  = $RootFilePath
$global:ARMFilePath = $CSVFilePath

#Create or check for existing resource group
$azureADFResourceGroupName = @{$true='WTW' + '-' + $platform.ToUpper() + '-' + $LocationshortName.ToUpper() + '-Resource-Group-' + $resourceGroupName;$false='WTW' + '-' + $platform.ToUpper() + '-' + $LocationshortName.ToUpper() + '-' + $environment.ToUpper() + '-Resource-Group-' + $resourceGroupName}[$environment.ToUpper() -eq 'PROD']
#$azureADFResourceGroupName = 'WTW' + '-' + $platform.ToUpper() + '-' + $LocationshortName.ToUpper() + '-' + $environment.ToUpper() + '-Resource-Group-' + $resourceGroupName

$azureServiceFabricResourceGroup = Get-AzureRmResourceGroup -Name $azureADFResourceGroupName  -ErrorAction SilentlyContinue
if(!$azureServiceFabricResourceGroup)
{
  Write-Host "Resource group '$azureADFResourceGroupName' does not exist. To create a new resource group, please enter a location.";
  Write-Host "Creating resource group '$azureADFResourceGroupName' in location '$Location'";
  New-AzureRmResourceGroup -Name $azureADFResourceGroupName -Location $Location
}
else{
  Write-Host "Using existing resource group '$azureADFResourceGroupName'";
}

#$namingPrefix = 'WTW' + '-' + $platform.ToUpper() + '-' + $LocationshortName.ToUpper() + '-' + $environment.ToUpper() + '-'
$namingPrefix = @{$true='WTW' + '-' + $platform.ToUpper() + '-' + $LocationshortName.ToUpper() + '-';$false='WTW' + '-' + $platform.ToUpper() + '-' + $LocationshortName.ToUpper() + '-' + $environment.ToUpper() + '-'}[$environment.ToUpper() -eq 'PROD']

$dataFactoryName = $namingPrefix + 'ADF-IntegrationLayer'

$parameters=@{
    dataFactoryName = $dataFactoryName
    azureSqlServerName = $azureSqlServerName
    azureSqlServerUserName = $azureSqlServerUserName
    azureSqlServerPassword = $azureSqlServerPassword
    azureTargetDatabaseName = $azureTargetDatabaseName

    OnPremSqlServerName = $OnPremSqlServerName
    OnPremSqlServerUserName = $OnPremSqlServerUserName
    OnPremSqlServerPassword = $OnPremSqlServerPassword
    OnPremSourceDatabaseName = $OnPremSourceDatabaseName
    OnPremGateway = $OnPremGateway
    Location = $Location
    offset_startTimePosition = $Offset
    StartTime = $StartTime
    StopTime = $EndTime
    StartTime_FullLoad = $StartTime_FullLoad
    StopTime_FullLoad = $EndTime_FullLoad   


}


# Start the deployment

$deploymentLabel =   $environment.ToLower() + 'ADFProvisioning'
Write-Host "Starting deployment...";
#===============================================================
#---------------------------------------------------------------
 

$global:templateFilePath  = $RootFilePath
$global:ARMFilePath = $CSVFilePath

$global:StartTime  = $StartTime
$global:EndTime = $EndTime

$global:StartTime_FullLoad  = $StartTime_FullLoad
$global:EndTime_FullLoad = $EndTime_FullLoad

$global:Offset  = $Offset 

# Iterate through a list of all CSV files in the folder and pipe it to ForEach-Object 
 #~Get-ChildItem  $global:templateFilePath -Name -Filter *.csv | ForEach-Object {
  Get-ChildItem  $global:ARMFilePath -Name -Filter *.csv | ForEach-Object {

 
    # derive source folder path and file name 
    #~$filePath =  $global:templateFilePath +"\"+ $_   
    $filePath =  $global:ARMFilePath +"\"+ $_   
    Write-Host " >>> filePath : " $filePath

    # Imports CSV file
    $global:csvFile = Import-Csv $filePath 
    $global:masterTemplatePath =""
     
    #Call ARM Automation script to generate ARM template
    invoke-expression -Command "$global:templateFilePath\GenerateTemplate.ps1" 
  
    Test-AzureRmResourceGroupDeployment -ResourceGroupName $azureADFResourceGroupName  -TemplateParameterObject $parameters -TemplateFile $global:masterTemplatePath   -Verbose
    New-AzureRmResourceGroupDeployment -Name $deploymentLabel  -ResourceGroupName $azureADFResourceGroupName  -TemplateParameterObject $parameters -TemplateFile $global:masterTemplatePath   -Verbose
    
    Write-Host "Deployment completed for ";
    $global:masterTemplatePath
    $global:ARMFilePath
 Write-Host "===========================================================================================";
} #iterating each csv file