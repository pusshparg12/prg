  
 # to run this code manually, set below commented variables
#$global:templateFilePath = 'C:\cft\wtw\Trunk\IntegrationLayer\ReferenceData\ARMTemplate\ARMTemplate\AutoGenARM'
#$global:ARMFilePath = 'C:\cft\wtw\Trunk\IntegrationLayer\ReferenceData\ARMTemplate\ARMTemplate\Users\Principal\Outbound'
    

    $csv = $global:csvFile
       
    $schemaRow =''
    $ARMvariableRow =''
    $LoadType = ''
    $ARMTemplatePrefix = ''
    $PipelineActivity = ''
    $DomainName= ''
    $DBSchemaName = ''
    $AzureTablePrefix = ''
    $colmapping = '"columnMappings": "'
    $rowcount = $csv.Length
    $ClosingBracket = '",'
    $ARMTemplateSuffix = ''
    $InboundOrOutbound = $null  #inbound/outbound 
    $SourceDataSetName = ''
    $TargetDataSetName  = ''
    $PipelineName = ''
    $sqlStoredProc = ''
    $SqlTypeTableName  = ''
    $PipelineDependOnOtherDS = ''
    $dstemplates=''

#-------------- [Start] Reading table schema from CSV file and generating schema related variables
    #iterate each row in schema file to create table schema, and formulate name for datasets, pipelines as per table name
    foreach($InputLineFeed in $csv | Select-Object -first $rowcount ) #excluding last line as it is sql query
    {
    echo $InputLineFeed.ColumnName
        if($InputLineFeed.ColumnName -eq 'DomainName')  #pick domain name to formulate Domain variable and db scheman name
        { 

            $ARMvariableRow = $ARMvariableRow +'"DomainName": "'  + $InputLineFeed.Type + '",' 
            $DomainName = $InputLineFeed.Type 
            $DBSchemaName =  '[['+ $DomainName + '].['
            
        }
        elseif($InputLineFeed.ColumnName -eq 'LoadType')  #Data load type if full load then all artifacts will be with _Full
        { 
            $LoadType = $InputLineFeed.Type

        }
        elseif($InputLineFeed.ColumnName -eq 'ARMTemplatePrefix')  #ARM Template name to be prefixed by this value, so all pipeline, dataset name will start with this
        { 
            $ARMTemplatePrefix = $InputLineFeed.Type
        }
        elseif($InputLineFeed.ColumnName -eq 'ARMTemplateSuffix')  #ARM Template name to be suffixed by this value, so all pipeline, dataset name will start with this
        { 
            $ARMTemplateSuffix = $InputLineFeed.Type
        } 
        elseif($InputLineFeed.ColumnName -eq 'InboundOrOutbound')  #ARM Template name to be suffixed by this value, so all pipeline, dataset name will start with this
        { 
            $InboundOrOutbound = $InputLineFeed.Type
        } 
        elseif($InputLineFeed.ColumnName -eq 'SourceDataSetName')  #ARM Template name to be suffixed by this value
        { 
            $SourceDataSetName = $InputLineFeed.Type
        } 
        elseif($InputLineFeed.ColumnName -eq 'TargetDataSetName')  #ARM Template name to be suffixed by this value
        { 
            $TargetDataSetName = $InputLineFeed.Type
        } 
        elseif($InputLineFeed.ColumnName -eq 'PipelineName')  #ARM Template name to be suffixed by this value
        { 
            $PipelineName = $InputLineFeed.Type
        } 
        elseif($InputLineFeed.ColumnName -eq 'sqlStoredProc')  #ARM Template name to be suffixed by this value
        { 
            $sqlStoredProc = $InputLineFeed.Type
        }  
        elseif($InputLineFeed.ColumnName -eq 'SqlTypeTableName')  #ARM Template name to be suffixed by this value
        { 
            $SqlTypeTableName = $InputLineFeed.Type
        } 
        elseif($InputLineFeed.ColumnName -eq 'PipelineActivity')  #ARM Template name to be prefixed by this value, so all pipeline, dataset name will start with this
        { 
            $PipelineActivity = $InputLineFeed.Type
            if($PipelineActivity -eq 'CopyActivity')  #in case of copy activity of pipeline, target table name needs to be prefixed with table schema
            {
                $AzureTablePrefix =  '[['+ $DomainName + '].['
                $ClosingBracket = ']",'
            }
        }
        #incase of chaining the pipeline, to execute only after earlier pipeline is completed successfully
        elseif($InputLineFeed.ColumnName -eq 'PipelineDependOnOtherDS')  # in case of chaining the pipeline, list of dependent datasets in comma seperated to be provided for this column
        { 
            $DSlist =  $InputLineFeed.Type; 
            $DSlist = $DSlist.split("|");                            #more than one datasets to be provided in | seperated, so these ds name will be added into ARM variables
             
            for($i=0;$i-le $DSlist.length-1;$i++) 
            { 
                 $PipelineDependOnOtherDS = $PipelineDependOnOtherDS +',{ "name": "'+ $DSlist[$i] + '" }'     #ARM variable suffixed with index number for each ds. For ex. PipelineDependOnOtherDS1='workerDSazureSql'....PipelineDependOnOtherDS2='workerContactDSazureSql', such each variablle will hold its ds name for chaining the pipeline
 
            } 
            echo '>>>>>>>>>>>>>>>>>>>>>>>'
            echo $PipelineDependOnOtherDS 
        }
        elseif($InputLineFeed.ColumnName -eq 'DBSchemaName') 
        { 
            $DBSchemaName = $InputLineFeed.Type
        }
        # last line is for variable creation
        elseif($InputLineFeed.ColumnName -eq 'Tablename')  # basis table name formulate ARM variables like dataset/pipeline/storedproc
        { 
             $AzureTable = $InputLineFeed.Type 
        
            #--- SETTING DEFAULT VALUES for ARM variables, incase if no value given in schema csv file for these properties then set these default values 
			#-------------------------------------------------------------------------
            if (!$SourceDataSetName) { $SourceDataSetName = $AzureTable + 'OnPremSQLTable' } # for empty SourceDataSetName set default  
            if (!$TargetDataSetName) { $TargetDataSetName = $AzureTable + 'AzureSQLTable' } # TargetDataSetName is not mentioned then set default 
            if (!$PipelineName)   # while setting default name for PipelineName, also setting default prefix for pipeline-activity, as this is how it was set for all pipeline from starting, so not to change any objects naming which was created in the begining, for avoiding name change
			{ 
				$PipelineName =  $AzureTable  + 'InboundPipeline' 
				$PipelineActivity = 'Inbound'+ $PipelineActivity
			} 
            if (!$sqlStoredProc)  { $sqlStoredProc =  $DBSchemaName + 'spLoad' + $AzureTable + ']'   } # sqlStoredProc is not mentioned then set default  
            if (!$SqlTypeTableName) { $SqlTypeTableName =   $DBSchemaName + $AzureTable + 'Type]'   } # SqlTypeTableName is not mentioned then set default  
            
			#-------------------------------------------------------------------------

			# setting variable values, these variables will be used in ARM template
            $ARMvariableRow = $ARMvariableRow +'"azureSqlTableName": "'  +  $AzureTablePrefix +$AzureTable + $ClosingBracket
            $ARMvariableRow = $ARMvariableRow +'"OnPremSqlDataSetName": "' +$ARMTemplatePrefix+ $SourceDataSetName +$LoadType+ $InboundOrOutbound +$ARMTemplateSuffix+'",' 
            $ARMvariableRow = $ARMvariableRow +'"azureSqlDataSetName": "' +$ARMTemplatePrefix+ $TargetDataSetName +$LoadType+ $InboundOrOutbound +$ARMTemplateSuffix+'",'  
            $ARMvariableRow = $ARMvariableRow +'"PipelineName": "' +$ARMTemplatePrefix+ $PipelineName +$LoadType+ $InboundOrOutbound +$ARMTemplateSuffix+'",' 
            $ARMvariableRow = $ARMvariableRow +'"ActivityName": "' +$ARMTemplatePrefix+ $AzureTable +  $PipelineActivity +$LoadType+ $InboundOrOutbound +$ARMTemplateSuffix+'",' 
            $ARMvariableRow = $ARMvariableRow +'"SqlTypeTableName": "'+ $SqlTypeTableName + '",'   
            $ARMvariableRow = $ARMvariableRow +'"sqlStoredProc": "'+ $sqlStoredProc + '",'   
            $ARMvariableRow = $ARMvariableRow +'"LoadType": "'+ $LoadType + '",'  

            if($LoadType -eq 'FullLoad')
            {
                $ARMvariableRow = $ARMvariableRow +'"StartTime": "'+ $global:StartTime_FullLoad + '",'  
                $ARMvariableRow = $ARMvariableRow +'"StopTime": "'+ $global:EndTime_FullLoad + '",'  
            }
            else
            {
                $ARMvariableRow = $ARMvariableRow +'"StartTime": "'+ $global:StartTime + '",'  
                $ARMvariableRow = $ARMvariableRow +'"StopTime": "'+ $global:EndTime + '",'
            }
            $ARMvariableRow = $ARMvariableRow +'"Offset": "'+ $global:Offset + '",'  
            $ARMvariableRow
        
        }
        elseif($InputLineFeed.ColumnName -eq 'TableToAudit')  #To run count on this table and pass it to Audit-batch table
        {  
			$ARMvariableRow = $ARMvariableRow +'"TableToAudit": "['  + $InputLineFeed.Type + '",'  
        } 
        elseif($InputLineFeed.ColumnName -eq 'OnPremSqlTableName')  # on prem view/table name for input dataset
        {
            $ARMvariableRow = $ARMvariableRow +'"OnPremSqlTableName": "['  + $InputLineFeed.Type + '",'  
        }
        elseif($InputLineFeed.ColumnName -eq 'sqlQuery')  # 
        {
            $ARMvariableRow = $ARMvariableRow +'"sqlReaderQuery": "'  + $InputLineFeed.Type + '",'  
        }
        
        else # if row is not variable then - formulate dataset schema which is common for on-prem and azure datset
        {
            $schemaRow = $schemaRow +'{"name": "' + $InputLineFeed.ColumnName + '", "type": "' + $InputLineFeed.Type + '"},' 
            $colmapping = $colmapping + $InputLineFeed.ColumnName + ':'+ $InputLineFeed.ColumnName + ','
        } 
    }   

    Write-Host  ">> DomainName: " $DomainName
    Write-Host  ">> ARM templates are created at : " $global:ARMFilePath 
    
    $variablesOutput = $global:ARMFilePath +'\ARMvariables.json'
    $tableSchemaOutput = $global:ARMFilePath +'\TableSchema.json'
    $PipelineDependOnOtherDSOutput = $global:ARMFilePath +'\PipelineDependOnOtherDS.json'


    # write to table schema file which will be used for datasets
    $schemaRow.Substring(0,$schemaRow.Length-1) | Out-File -FilePath $tableSchemaOutput -Encoding utf8
     
    $colmapping = $colmapping.Substring(0,$colmapping.Length-1) + '",'
    $ARMvariableRow = $ARMvariableRow + $colmapping  

     # write to variable file for ARM
    $ARMvariableRow | Out-File -FilePath $variablesOutput -Encoding utf8  
    
    # write to InboundActivity file for any dependent dataset if given in csv file, for chaining the pipeline
    if($PipelineDependOnOtherDS.Length -gt 0)
     {$PipelineDependOnOtherDS | Out-File -FilePath $PipelineDependOnOtherDSOutput -Encoding utf8}
   # {$PipelineDependOnOtherDS.Substring(0,$PipelineDependOnOtherDS) | Out-File -FilePath $PipelineDependOnOtherDSOutput -Encoding utf8}

#-------------- [End]    

# ----- common variables referred in all ARM is being copied from AutoGen folder to ARM location, for adding these variables to ARM template's hash tag for these vars
 $CommonVarCSV = $global:templateFilePath+"\"+"ARMCommonvariables.json"
 Copy-Item $CommonVarCSV $global:ARMFilePath
 $CommonVarCSV = $global:templateFilePath+"\"+"AuditVariables.json"  #-- Audit related variables are copied to local folder of ARM
 Copy-Item $CommonVarCSV $global:ARMFilePath
 $CommonVarCSV = $global:templateFilePath+"\AuditLogging\*"  #-- Audit related all the files from audit folder are copied to local folder of ARM
 Copy-Item $CommonVarCSV $global:ARMFilePath
  
#---------------------------------------------------------------

# forming ARM template name 
$masterTemplate = Get-ChildItem  $global:ARMFilePath | Where-Object {$_.Name -eq 'Ref-Master-template_AUTOMATED.json'}
$masterTemplatePath  = $masterTemplate.FullName

$ARMFileName = $global:ARMFilePath +'\'+$AzureTable+"_"+$LoadType+"_ARMtemplate.json"

#replacing hash tag with actual value
$templateHash = @{"ARMvariables" = "#####ARMvariables#####";"ARMCommonvariables" = "#####ARMCommonvariables#####";"AzureDataSet" = "#####AzureDataSet#####";"OnPremDataSet" = "#####OnPremDataSet#####";"InboundActivity" = "#####InboundActivity#####";"TableSchema" = "#####TableSchema#####";"AuditingStartOutputDS" = "#####AuditingStartOutputDS#####";"AuditingEndOutputDS" = "#####AuditingEndOutputDS#####";"UpdateCountAuditingDS" = "#####UpdateCountAuditingDS#####";"InboundActivity-AuditingStart" = "#####InboundActivity-AuditingStart#####";"InboundActivity-AuditingEnd" = "#####InboundActivity-AuditingEnd#####";"AuditVariables" = "#####AuditVariables#####";"PipelineDependOnOtherDS" = "#####PipelineDependOnOtherDS#####" } 


$dstemplates = Get-ChildItem $global:ARMFilePath -Exclude ("*.ps1","*.csv")

$masterJson = Get-Content $masterTemplatePath | Foreach-Object { $_ -replace '"#####','#####' } | Foreach-Object { $_ -replace '#####"','#####' }
echo '~~~~~~>>>>>>>'
     echo $dstemplates
#iterate thru all json template files
foreach ($file in $dstemplates)
{
    $filename = $file.Name 
    $filename = $filename -replace ".json" , ""
    

    if ($templateHash.Get_Item($filename))  #if json filename matches with hash tag value
    {
    echo $filename
        $tagval = $templateHash.Get_Item($filename)
        $dsfilePath = $file.FullName
        $contentjson = Get-Content $dsfilePath -Raw 
        

        $masterJson = Get-Content $masterTemplatePath -Raw | Foreach-Object {$_ -replace $tagval,$contentjson }  
            #echo $masterJson
        $masterTemplatePath  = $ARMFileName 
        $masterJson | Out-File -FilePath $masterTemplatePath 

        if($filename -eq 'PipelineDependOnOtherDS')
        {
        echo '-----------------------------------------------------------------------------------------------'
        echo $tagval
        echo $contentjson
        echo '========================================='
        echo $masterJson
          echo '-----------------------------------------------------------------------------------------------'

          }
    } 
 
}
$global:masterTemplatePath = $masterTemplatePath
 Write-Host  " >>> global:masterTemplatePath: "  $global:masterTemplatePath
#---------------------------------------------------------------
     # TODO:
     #  
     # clear the file before writting to it 
     # key value pair file for ARM variables

